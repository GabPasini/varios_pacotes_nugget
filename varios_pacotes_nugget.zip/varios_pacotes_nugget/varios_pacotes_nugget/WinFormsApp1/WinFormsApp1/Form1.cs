using MySql.Data.MySqlClient;
using System.Data;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        int idenable = 0;
        public Form1()
        {
            InitializeComponent();
            txtId.ReadOnly = true;
            txtId.Enabled = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CarregarDadosGrid();
        }

        private void CarregarDadosGrid()
        {
            try
            {
                using (MySqlConnection conexao = new MySqlConnection())
                {
                    conexao.Open();
                    string query = "SELECT id, nome, carga_horaria, valor FROM usuarios";

                    using (MySqlDataAdapter da = new MySqlDataAdapter(query, conexao))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtNome.Text) || string.IsNullOrWhiteSpace(txtCargaHoraria.Text) || string.IsNullOrWhiteSpace(txtValor.Text))
            {
                MessageBox.Show("Preencha todos os campos antes de salvar!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (MySqlConnection conexao = new MySqlConnection())
                {
                    conexao.Open();
                    string query = "INSERT INTO usuarios (id, nome) VALUES (@id, @nome)";

                    using (MySqlCommand cmd = new MySqlCommand(query, conexao))
                    {
                        // Utilização de parâmetros para segurança contra SQL Injection
                        cmd.Parameters.AddWithValue("@id", txtId.Text);
                        cmd.Parameters.AddWithValue("@nome", txtNome.Text);
                        cmd.Parameters.AddWithValue("@carga_horaria", txtCargaHoraria.Text);
                        cmd.Parameters.AddWithValue("@valor", txtValor.Text);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Registro salvo com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Limpa os campos de texto
                txtId.Clear();
                txtNome.Clear();
                txtCargaHoraria.Clear();
                txtValor.Clear();
                txtId.Focus();

                // Atualiza a tabela no DataGridView
                CarregarDadosGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar no banco de dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}