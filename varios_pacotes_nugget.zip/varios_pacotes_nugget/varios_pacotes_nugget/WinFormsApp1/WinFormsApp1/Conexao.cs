﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    internal class Conexao
    {
        static void Form1()
        {
            string conexaoString = "server=localhost;database=bd_nuggets;uid=root;pwd=admin;";

            using (MySqlConnection conexao = new MySqlConnection(conexaoString))
            {
                try
                {
                    conexao.Open();
                    Console.WriteLine("Conexão realizada com sucesso!");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro ao conectar: " + ex.Message);
                }
            }
        }
    }
}
