﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblId = new Label();
            txtId = new TextBox();
            txtNome = new TextBox();
            txtCargaHoraria = new TextBox();
            txtValor = new TextBox();
            lblNome = new Label();
            lblCargaHoraria = new Label();
            lblValor = new Label();
            btnSalvar = new Button();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.Location = new Point(444, 54);
            lblId.Name = "lblId";
            lblId.Size = new Size(24, 20);
            lblId.TabIndex = 0;
            lblId.Text = "ID";
            lblId.Click += label1_Click;
            // 
            // txtId
            // 
            txtId.Location = new Point(478, 50);
            txtId.Margin = new Padding(3, 4, 3, 4);
            txtId.Name = "txtId";
            txtId.Size = new Size(207, 27);
            txtId.TabIndex = 1;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(478, 101);
            txtNome.Margin = new Padding(3, 4, 3, 4);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(207, 27);
            txtNome.TabIndex = 2;
            // 
            // txtCargaHoraria
            // 
            txtCargaHoraria.Location = new Point(478, 157);
            txtCargaHoraria.Margin = new Padding(3, 4, 3, 4);
            txtCargaHoraria.Name = "txtCargaHoraria";
            txtCargaHoraria.Size = new Size(207, 27);
            txtCargaHoraria.TabIndex = 3;
            // 
            // txtValor
            // 
            txtValor.Location = new Point(478, 208);
            txtValor.Margin = new Padding(3, 4, 3, 4);
            txtValor.Name = "txtValor";
            txtValor.Size = new Size(207, 27);
            txtValor.TabIndex = 4;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(418, 105);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(50, 20);
            lblNome.TabIndex = 5;
            lblNome.Text = "Nome";
            // 
            // lblCargaHoraria
            // 
            lblCargaHoraria.AutoSize = true;
            lblCargaHoraria.Location = new Point(373, 161);
            lblCargaHoraria.Name = "lblCargaHoraria";
            lblCargaHoraria.Size = new Size(102, 20);
            lblCargaHoraria.TabIndex = 6;
            lblCargaHoraria.Text = "Carga Horária";
            // 
            // lblValor
            // 
            lblValor.AutoSize = true;
            lblValor.Location = new Point(426, 212);
            lblValor.Name = "lblValor";
            lblValor.Size = new Size(43, 20);
            lblValor.TabIndex = 7;
            lblValor.Text = "Valor";
            // 
            // btnSalvar
            // 
            btnSalvar.Location = new Point(373, 265);
            btnSalvar.Margin = new Padding(3, 4, 3, 4);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(86, 31);
            btnSalvar.TabIndex = 8;
            btnSalvar.Text = "Salvar";
            btnSalvar.UseVisualStyleBackColor = true;
            btnSalvar.Click += btnSalvar_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(228, 367);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(620, 165);
            dataGridView1.TabIndex = 9;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1127, 655);
            Controls.Add(dataGridView1);
            Controls.Add(btnSalvar);
            Controls.Add(lblValor);
            Controls.Add(lblCargaHoraria);
            Controls.Add(lblNome);
            Controls.Add(txtValor);
            Controls.Add(txtCargaHoraria);
            Controls.Add(txtNome);
            Controls.Add(txtId);
            Controls.Add(lblId);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblId;
        private TextBox txtId;
        private TextBox txtNome;
        private TextBox txtCargaHoraria;
        private TextBox txtValor;
        private Label lblNome;
        private Label lblCargaHoraria;
        private Label lblValor;
        private Button btnSalvar;
        private DataGridView dataGridView1;
    }
}
